-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 27, 2015 at 05:54 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `uas1`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE IF NOT EXISTS `barang` (
  `KodeBrg` varchar(10) NOT NULL,
  `NamaBrg` varchar(50) NOT NULL,
  `HargaBeli` int(10) NOT NULL,
  `HargaJual` int(10) NOT NULL,
  `Stock` int(10) NOT NULL,
  `StokJual` int(11) NOT NULL,
  `StokBeli` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`KodeBrg`, `NamaBrg`, `HargaBeli`, `HargaJual`, `Stock`, `StokJual`, `StokBeli`) VALUES
('B001', 'Pudak', 20000, 22000, 20, 1, 18),
('B002', 'Kerupuk', 4500, 5000, 50, 16, 20),
('B003', 'Siwalan', 5000, 6500, 9, 1, 0),
('B004', 'Jubung', 8000, 10000, 12, 4, 0),
('Z003', 'Bandeng', 9000, 12000, 90, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE IF NOT EXISTS `pegawai` (
  `KodePeg` varchar(10) NOT NULL,
  `NamaPeg` varchar(50) NOT NULL,
  `JenisKel` varchar(10) NOT NULL,
  `TglLhr` date NOT NULL,
  `Alamat` varchar(50) NOT NULL,
  `Telp` varchar(12) NOT NULL,
  `Keterangan` varchar(30) NOT NULL,
  `Email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`KodePeg`, `NamaPeg`, `JenisKel`, `TglLhr`, `Alamat`, `Telp`, `Keterangan`, `Email`) VALUES
('P001', 'Agustin', 'Laki-Laki', '2015-06-23', 'Jl. Wonokromo 23 Surabaya', '03112398490', 'Pegawai', 'Agustin@kelapamuda.com'),
('P002', 'Rani', 'Perempuan', '2015-06-10', 'Jl. Demak 12 Surabaya', '085671231212', 'Pegawai', 'Rani@kelapamuda.com'),
('P003', 'Agung', 'Laki-Laki', '2015-06-05', 'Jl. Banjar 90 Surabaya', '0819829181', 'Pegawai', 'Agung@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE IF NOT EXISTS `supplier` (
  `KodeSup` varchar(10) NOT NULL,
  `NamaSup` varchar(50) NOT NULL,
  `Alamat` varchar(50) NOT NULL,
  `Telp` varchar(12) NOT NULL,
  `Keterangan` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`KodeSup`, `NamaSup`, `Alamat`, `Telp`, `Keterangan`) VALUES
('S001', 'PT Gudang Buah', 'Jl. Manyar 21 Surabaya', '081123218920', 'Supplier Siwalan'),
('S002', 'PT Kelapa Jaya', 'Jl. Manggis 20 Tuban', '081762181820', 'Supplier Kerupuk'),
('S003', 'CV Putra Gresik', 'Jl. Maluku 23', '09312321981', 'Supplier Jubung');

-- --------------------------------------------------------

--
-- Table structure for table `tblpenjualan`
--

CREATE TABLE IF NOT EXISTS `tblpenjualan` (
  `idtransaksi` varchar(30) NOT NULL,
  `tanggal` date NOT NULL,
  `grandtotal` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpenjualan`
--

INSERT INTO `tblpenjualan` (`idtransaksi`, `tanggal`, `grandtotal`) VALUES
('PK00001', '2015-06-26', 22000);

-- --------------------------------------------------------

--
-- Table structure for table `tblpenjualandetail`
--

CREATE TABLE IF NOT EXISTS `tblpenjualandetail` (
`iddetail` int(10) NOT NULL,
  `idtransaksi` varchar(10) NOT NULL,
  `KodeBrg` varchar(10) NOT NULL,
  `Stock` int(11) NOT NULL,
  `HargaJual` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpenjualandetail`
--

INSERT INTO `tblpenjualandetail` (`iddetail`, `idtransaksi`, `KodeBrg`, `Stock`, `HargaJual`) VALUES
(1, 'PK00001', 'B001', 1, 22000);

-- --------------------------------------------------------

--
-- Table structure for table `tbltransaksi`
--

CREATE TABLE IF NOT EXISTS `tbltransaksi` (
  `idtransaksi` varchar(30) NOT NULL,
  `tanggal` date NOT NULL,
  `grandtotal` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltransaksi`
--

INSERT INTO `tbltransaksi` (`idtransaksi`, `tanggal`, `grandtotal`) VALUES
('KM00001', '2015-06-26', 22000),
('KM00002', '2015-06-27', 34000);

-- --------------------------------------------------------

--
-- Table structure for table `tbltransaksidetail`
--

CREATE TABLE IF NOT EXISTS `tbltransaksidetail` (
`iddetail` int(10) NOT NULL,
  `idtransaksi` varchar(10) NOT NULL,
  `KodeBrg` varchar(10) NOT NULL,
  `supplier` varchar(50) NOT NULL,
  `Stock` int(11) NOT NULL,
  `HargaJual` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltransaksidetail`
--

INSERT INTO `tbltransaksidetail` (`iddetail`, `idtransaksi`, `KodeBrg`, `supplier`, `Stock`, `HargaJual`) VALUES
(65, 'KM00001', 'B001', 'PT Kelapa Jaya', 1, 22000),
(66, 'KM00002', 'B001', 'CV Putra Gresik', 1, 22000),
(67, 'KM00002', 'Z003', 'CV Putra Gresik', 1, 12000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
 ADD PRIMARY KEY (`KodeBrg`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
 ADD PRIMARY KEY (`KodePeg`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
 ADD PRIMARY KEY (`KodeSup`);

--
-- Indexes for table `tblpenjualan`
--
ALTER TABLE `tblpenjualan`
 ADD PRIMARY KEY (`idtransaksi`);

--
-- Indexes for table `tblpenjualandetail`
--
ALTER TABLE `tblpenjualandetail`
 ADD PRIMARY KEY (`iddetail`,`idtransaksi`,`KodeBrg`);

--
-- Indexes for table `tbltransaksi`
--
ALTER TABLE `tbltransaksi`
 ADD PRIMARY KEY (`idtransaksi`);

--
-- Indexes for table `tbltransaksidetail`
--
ALTER TABLE `tbltransaksidetail`
 ADD PRIMARY KEY (`iddetail`,`idtransaksi`,`KodeBrg`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblpenjualandetail`
--
ALTER TABLE `tblpenjualandetail`
MODIFY `iddetail` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbltransaksidetail`
--
ALTER TABLE `tbltransaksidetail`
MODIFY `iddetail` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=68;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
